import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import com.fazecast.jSerialComm.SerialPort;
import org.opencv.imgcodecs.Imgcodecs;

public class cam{
    static {
        System.load(System.getProperty("user.dir") + "/native/opencv_java490.dll");
    }

    public static void main(String[] args) {
        CascadeClassifier faceDetector = new CascadeClassifier("haarcascade_frontalface_default.xml");
        SerialPort port = SerialPort.getCommPort("COM4"); // replace COM3 with your port
        port.setComPortParameters(9600, 8, 1, 0); // 9600 baud rate
        port.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 0, 0);
        if (!port.openPort()) {
        System.out.println("Failed to open port.");
         return;
         }
         System.out.println("Serial port opened successfully.");

        Mat frame= new Mat();
        Mat grey=new Mat();
        
        VideoCapture cam = new VideoCapture(0);

        boolean captured=false;
        while(true){
          cam.read(frame);
          Imgproc.cvtColor(frame, grey, Imgproc.COLOR_BGR2GRAY);
          MatOfRect faces = new MatOfRect();
          faceDetector.detectMultiScale(grey, faces);

          for (Rect face : faces.toArray()) {
                Imgproc.rectangle(frame, face, new Scalar(0, 255, 0), 2);
            }
            if (faces.toArray().length > 0) {
                if(!captured){
              Imgcodecs.imwrite("captured_pic.jpg", frame);
             // System.out.println("face detected");
            }
             port.writeBytes("1".getBytes(),1);
             
            }
            else{
                port.writeBytes("0".getBytes(),1);
            }

         HighGui.imshow("Face Detection", frame);

           if(HighGui.waitKey(30)==27){
            port.writeBytes("0".getBytes(),1);
            break;
           }
        }
        cam.release();
         port.closePort();
        System.exit(0);
       
    }
}
